﻿using System;
using System.Collections.Generic;

namespace Store_Boxes
{
    class Program
    {
        static void Main()
        {
            List<Box> boxes = new List<Box>();
            List<Item> items = new List<Item>();

            while (true)
            {
                string[] serialNumberItemNameItemQuantityItemPrice = Console.ReadLine()
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries);

                string serialNumber = serialNumberItemNameItemQuantityItemPrice[0];

                if (serialNumber == "end")
                    break;

                string itemName = serialNumberItemNameItemQuantityItemPrice[1];
                int itemQuantity = int.Parse(serialNumberItemNameItemQuantityItemPrice[2]);
                decimal itemPrice = decimal.Parse(serialNumberItemNameItemQuantityItemPrice[3]);

                Box box = new Box()
                {
                    SerialNumber = serialNumber,
                    ItemQuantity = itemQuantity,
                    PriceBox = itemPrice
                };

                boxes.Add(box);
                
                box.Item = new Item()
                {
                    Name = itemName,
                    Price = itemPrice
                };

                items.Add(box.Item);
            }

            foreach (Box box1 in boxes)
            {
                Console.WriteLine(PriceOneBox);
            }
            

        }
    }
}
    

