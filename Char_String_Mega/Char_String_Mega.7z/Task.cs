﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Char_String_Mega
{
    class Task
    {

        public void Tasks()
        {
            /*
            Console.WriteLine(" 2 - Reverse"); // Ok
            Console.WriteLine("3"); // Ok
            Console.WriteLine("4"); // Ok
            Console.WriteLine("5 - CountSubstring."); // Ok

            Console.WriteLine("6"); // No

            Console.WriteLine("7"); // Ok

            Console.WriteLine("8 - Unicode"); // No

            Console.WriteLine("10"); // No

            Console.WriteLine("11 - TextFilter.");  // Ok

            Console.WriteLine("12");

            Console.WriteLine("13"); // No, no
            Console.WriteLine("14");  // 50/50
            Console.WriteLine("15"); // Ok
            Console.WriteLine("21 - Palindromes counts"); // 50/50
            Console.WriteLine("22"); // Ok
            Console.WriteLine("23"); // Ok
            Console.WriteLine("24");
            */
        }
    }
}
